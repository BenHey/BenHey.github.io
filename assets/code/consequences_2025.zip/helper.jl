include("contextual_neural_urn.jl")

using Flux


function pair_score(voter::Vector{Float32},alternative::Vector{Float32})::Float32
    return -sum((voter.-alternative).^2)
end

function get_data(nb_alternative::Int64,nb_voter::Int64,alpha::Float32)
    feature_maps = [voter ->get_x(voter,alpha),voter ->get_y(voter,alpha)]
    alternative_list = [alternative_generator1() for _ in 1:nb_alternative]
    voter_list = [voter_generator1() for _ in 1:nb_voter]
    voter_features =[get_atom(voter,feature_maps) for voter in voter_list]
    atom_set =Set(voter_features)
    return feature_maps,alternative_list,voter_list,atom_set
end

function get_baselines(voter_list::Vector{Vector{Float32}},alternative_list::Vector{Vector{Float32}},atom_set,feature_maps)
    global_borda = borda(voter_list,alternative_list)
    local_borda = build_local_borda(voter_list,alternative_list,atom_set,feature_maps)
    global_lottery = nash(build_margin_matrix(voter_list,alternative_list))[2]
    M_local_dico = build_local_margin_matrix(voter_list,alternative_list,atom_set,feature_maps)
    local_lotteries = Dict(atom => Float32.(nash(M_local_dico[atom])[2]) for atom in atom_set)
    return global_borda,local_borda,global_lottery,local_lotteries,M_local_dico
end

function build_distillation_data(alternative_list,voter_list;opt= Descent(0.0005),nb_steps=100000,p_random=0.001,binarize=true,N_balls=100)
    nb_alternative = length(alternative_list)
    nb_feature = 1
    nb_voter = length(voter_list)
    neural_urn = initialize_urn(nb_alternative,nb_feature,opt)
    get_user()::Int64 = rand(1:nb_voter)
    get_user_features(user::Int64) = binarize ? get_atom(voter_list[user]) : voter_list[user]
    get_user_preferences(user) = [pair_score(voter_list[user],alternative) for alternative in alternative_list]
    loss = (model,x, y) -> sum((model(x) .- y).^2)
    neural_urn,data_distillation = run_urn(nb_alternative,
        neural_urn,
        get_user,
        get_user_preferences,
        get_user_features,
        nb_steps,
        opt,
        loss,
        p_random, N_balls)
    return neural_urn,data_distillation
end


function build_neural_urn(feature_maps,alternative_list,voter_list;opt= Opt(0.5),nb_steps=100,p_random=0.05,binarize=true,N_balls=300,nb_steps_distillation=100)
    nb_alternative = length(alternative_list)
    nb_feature = length(feature_maps)
    nb_voter = length(voter_list)
    neural_urn = initialize_urn(nb_alternative,nb_feature,opt)
    get_user()::Int64 = rand(1:nb_voter)
    get_user_features(user::Int64) = binarize ? get_atom(voter_list[user], feature_maps) : voter_list[user]
    get_user_preferences(user) = [pair_score(voter_list[user],alternative) for alternative in alternative_list]
    neural_urn,data_distillation = build_distillation_data(feature_maps,alternative_list,voter_list;opt= opt,nb_steps=nb_steps,p_random,binarize=binarize,N_balls=N_balls)
    distilled_urn = learn_distilled_urn(nb_alternative,nb_feature,data_distillation,nb_steps_distillation)
    proba_urn(x) = softmax(distilled_urn(x))
    proba_urn_ret(x) =proba_urn(get_atom(x,feature_maps))
    return proba_urn_ret
end



function plot_distillation_data_performance(distillation_data,local_lotteries,alternative_list,voter_list,feature_maps)
    ret = []
    for (voter_index,voter_bucket,lottery) in distillation_data
        lottery2 = local_lotteries[get_atom(voter_list[voter_index],feature_maps)]
        push!(ret,voter_win_rate(lottery,lottery2,alternative_list,voter_list[voter_index]))
    end
    cummean(A) = cumsum(A) ./ (1:length(A))
    aux = cummean(ret)
    aux2=[aux[i] for i in 1:length(aux) if i%100==0]
    t = [i for i in 1:length(aux) if i%100==0]
    p = plot(t,aux2,label="performance against local lottery",xlabel="iteration",ylabel="win rate")
    return p
end









