# Custom experiment with 5 voters (V1-V5) and 3 alternatives (R,B,G)
# Hand-defined positions in 2D space



include("helper.jl");

using DataFrames
using Printf
using JuMP
using Statistics
using Plots



    println("🧪 Running custom experiment with 5 voters and 3 alternatives")
    
    # Hand-defined positions
    # Voters: V1, V2, V3, V4, V5
 voter_list = [
        Float32[0.0, 0.0,-1.],  # minority
        Float32[0.0, 0.01,-1.],  # minority
        Float32[1., 0.0,-1.],  # majority
        Float32[1., 0.01,-1.],  # majority
        Float32[1., 0.02,-1.] ,  # majority
        Float32[3., 3.,1.]  # an alien  from another planet
    ]
    
    # Alternatives: R (Red), B (Blue), G (Green)
    alternative_list = [
        Float32[0., 0.6,0.],  # Green
        Float32[.2, 0.2,0.],    # Red
        Float32[1.,-0.2,0.],  # Blue
        Float32[3.1,3.1,0.]  # an alien candidate from another planet
    ]
    
    nb_alternatives = length(alternative_list)
    nb_voters = length(voter_list)
    
    println("📍 Positions:")
    println("Voters:")
    for (i, pos) in enumerate(voter_list)
        println("  V$i: ($(pos[1]), $(pos[2])),$(pos[3])")
    end
    println("Alternatives:")
    alt_names = ["green", "red", "blue", "alien"]
    for (i, pos) in enumerate(alternative_list)
        println("  $(alt_names[i]): ($(pos[1]), $(pos[2]))")
    end
    

    # Get atoms for each voter using our custom get_atom function

    voter_features = [get_atom(voter) for voter in voter_list]
    atom_set = collect(Set(voter_features))
    
    # Color mapping for voters by atom
    color_names_available = [:red, :blue, :green, :orange, :purple, :cyan, :magenta, :yellow, :brown, :pink]
    color_dico = Dict(atom => color_names_available[i] for (i, atom) in enumerate(atom_set))
    
   

    







function one_xp(alternative_list,voter_list,nb_steps=10000)::Tuple{Vector{Float32}, Vector{Float32}}
_,distillation_data = build_distillation_data(alternative_list,voter_list,nb_steps=nb_steps)

res = sum([c for (a,b,c) in distillation_data if b[1]<0])
A = res/sum(res)

res = sum([c for (a,b,c) in distillation_data if b[1]>0])
B = res/sum(res)
return A, B
end


xp_list = []
for i in 1:10
    ret = one_xp(alternative_list,voter_list)
    push!(xp_list, ret)
end

# Extract A (-1) and B (+1) vectors
A_vectors = [ret[1] for ret in xp_list]  # A vectors (-1)
B_vectors = [ret[2] for ret in xp_list]  # B vectors (+1)

# Compute vectorial averages
A_mean = mean(A_vectors)
B_mean = mean(B_vectors)

# Compute vectorial standard deviations
A_std = std(A_vectors)
B_std = std(B_vectors)

println("\n📊 Results after $(length(xp_list)) experiments:")
println("A (-1) mean: ", A_mean)
println("A (-1) std:  ", A_std)
println("B (+1) mean: ", B_mean)
println("B (+1) std:  ", B_std)

# Create plot
p = plot(title="Vectorial Average and Std of A (-1) and B (+1)")

# Plot individual experiments as light scatter points
for (i, A_vec) in enumerate(A_vectors)
    if i == 1
        scatter!(p, 1:length(A_vec), A_vec, alpha=0.4, color=:red, markersize=3, label="A (-1) individual")
    else
        scatter!(p, 1:length(A_vec), A_vec, alpha=0.4, color=:red, markersize=3, label="")
    end
end

for (i, B_vec) in enumerate(B_vectors)
    if i == 1
        scatter!(p, 1:length(B_vec), B_vec, alpha=0.4, color=:blue, markersize=3, label="B (+1) individual")
    else
        scatter!(p, 1:length(B_vec), B_vec, alpha=0.4, color=:blue, markersize=3, label="")
    end
end

# Plot means as larger scatter points with error bars
scatter!(p, 1:length(A_mean), A_mean, yerror=A_std, 
         markersize=8, color=:red, markerstrokewidth=2, 
         label="A (-1) mean ± std")
scatter!(p, 1:length(B_mean), B_mean, yerror=B_std, 
         markersize=8, color=:blue, markerstrokewidth=2, 
         label="B (+1) mean ± std")

xlabel!(p, "Alternative Index")
ylabel!(p, "Probability")
savefig(p, "vectorial_analysis.png")

println("✅ Plot saved: vectorial_analysis.png")


