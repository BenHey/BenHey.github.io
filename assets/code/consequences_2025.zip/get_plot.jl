using Plots
using Statistics

# Data from your experiment results
A_mean = Float32[0.007086113, 0.01930346, 0.9721526, 0.0014577897]
A_std = Float32[0.004312147, 0.010488238, 0.013563553, 0.0010647642]
B_mean = Float32[0.005085857, 0.0026047598, 0.006148734, 0.98616064]
B_std = Float32[0.0037018952, 0.002595926, 0.0053445566, 0.008437018]

# Alternative names
alt_names = ["green", "red", "blue", "orange"]
x_positions = 1:length(alt_names)

# Calculate 95% confidence intervals (assuming t-distribution with n=10 experiments)
n = 10
t_critical = 2.262  # t-value for 95% CI with 9 degrees of freedom
A_ci = A_std ./ sqrt(n) .* t_critical
B_ci = B_std ./ sqrt(n) .* t_critical

# Create the plot
p = plot(size=(800, 600), dpi=300)

# Plot A (-1) group with confidence intervals
scatter!(p, x_positions .- 0.1, A_mean, 
         yerror=A_ci,
         markersize=8, 
         markershape=:circle,
         color=:red, 
         markerstrokewidth=2,
         markerstrokecolor=:darkred,
         label="group 1",
         capsize=4)

# Plot B (+1) group with confidence intervals  
scatter!(p, x_positions .+ 0.1, B_mean,
         yerror=B_ci,
         markersize=8,
         markershape=:square, 
         color=:blue,
         markerstrokewidth=2,
         markerstrokecolor=:darkblue,
         label="group 2",
         capsize=4)

# Customize the plot
plot!(p,
      title="neural urn prediction by group",
      xlabel="Alternatives",
      ylabel="Probability",
      xticks=(x_positions, alt_names),
      legend=:topright,
      grid=true,
      gridwidth=1,
      gridcolor=:lightgray,
      framestyle=:box)

# Add a horizontal line at y=0.25 (equal probability reference)
hline!(p, [0.25], color=:gray, linestyle=:dash, alpha=0.5, label="Equal Probability (0.25)")

# Set y-axis limits to better show the data
ylims!(p, (0, 1.1))

# Save the plot
savefig(p, "urn.png")
println("✅ Plot saved: preference_scatter_plot.png")

# Print summary statistics
println("\n📊 Summary Statistics:")
println("Group A (-1) Minority:")
for i in 1:length(alt_names)
    println("  $(alt_names[i]): $(round(A_mean[i], digits=4)) ± $(round(A_ci[i], digits=4))")
end
println("\nGroup B (+1) Majority:")
for i in 1:length(alt_names)
    println("  $(alt_names[i]): $(round(B_mean[i], digits=4)) ± $(round(B_ci[i], digits=4))")
end


  voter_list = [
        Float32[0.0, 0.0,-1.],  # minority
        Float32[0.0, 0.01,-1.],  # minority
        Float32[1., 0.0,-1.],  # majority
        Float32[1., 0.01,-1.],  # majority
        Float32[1., 0.02,-1.] ,  # majority
        Float32[3., 3.,1.]  # an alien  from another planet
    ]
    
    # Alternatives: R (Red), B (Blue), G (Green)
    alternative_list = [
        Float32[0., 0.6,0.],  # Green
        Float32[.2, 0.2,0.],    # Red
        Float32[1.,-0.2,0.],  # Blue
        Float32[3.1,3.1,0.]  # an alien candidate from another planet
    ]

alt_names = [:green, :red, :blue, :orange]
p = scatter([v[1] for v in voter_list], [v[2] for v in voter_list], color=:black, label="voter",markershape=:square, markersize=5, xlabel="X", ylabel="Y", title="Voters and Alternatives")
for (i, alt) in enumerate(alternative_list)
    scatter!(p, [alt[1]], [alt[2]], color=alt_names[i], markershape=:circle, markersize=10,label="" )
end
scatter!(p, [alternative_list[1][1]], [alternative_list[1][2]], color=alt_names[1],label="alternative ($(alt_names[1]))", markershape=:circle, markersize=10)

x = ((1:1000)/1000.) * 3
y = 2 .- x .* 2 ./ 3
plot!(p, x, y, color=:black, linewidth=5,label=""  )
annotate!(p, 1, 1, "group 1", color=:black, 8)
annotate!(p, 1.35, 1.35, "group 2", color=:black, 8)
annotate!(p, 0.05, 0., "2", color=:black, 6)
annotate!(p, 1.05, 0., "3", color=:black, 6)
annotate!(p, 3.05, 3., "1", color=:black, 6)
savefig(p, "visualization.png")
display(p)