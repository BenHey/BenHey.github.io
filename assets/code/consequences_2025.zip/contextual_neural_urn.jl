using Flux
using Random
using StatsBase
using Plots
using Flux.Optimise: Descent, Momentum,Adam,RMSProp,AdaGrad
using IterTools: ncycle

function get_atom(voter_coordinates::Vector{Float32})::Vector{Float32}
    return [voter_coordinates[3] ]
end

function initialize_urn(nb_alternative::Int64,nb_feature::Int64,opt,n_init_train::Int64=500)

    model = Chain(
        Dense(nb_feature, 32, relu),  
        Dense(32, 32, relu),          
        Dense(32, nb_alternative)    
    )
    return model
end


function get_voter_and_compare(nb_alternative::Int64,neural_urn::Chain,get_user::Function,get_user_preferences::Function,get_user_features::Function)::Tuple{Int64,Vector{Float32},Int64,Int64,Vector{Float32}}
    user = get_user()
    preference = get_user_preferences(user)
    user_feature = Float32.(get_user_features(user))
    urn_contextual_state = neural_urn(user_feature)
    urn_contextual_state = max.(urn_contextual_state,0.01f0)
    alternative_indexes = sample(1:nb_alternative, Weights(urn_contextual_state), 2, replace=false)
    index_alternative1 = alternative_indexes[1]
    index_alternative2 = alternative_indexes[2]
    if preference[index_alternative1]>preference[index_alternative2]
        return user,user_feature,index_alternative1,index_alternative2,urn_contextual_state
    end
    return user,user_feature,index_alternative2,index_alternative1,urn_contextual_state
end


function run_urn(nb_alternative::Int64,neural_urn::Chain,get_user::Function,get_user_preferences::Function,get_user_features::Function,nb_iter::Int64,opt,loss,p_random,N_balls::Int64)::Tuple{Chain,Vector{Tuple{Int64,Vector{Float32},Vector{Float32}}}}
    data_distillation =[]
    for _ in 1:nb_iter
        learning_data = []
        for _ in 1:16
        user,user_feature,winner,looser,urn_contextual_state = get_voter_and_compare(nb_alternative,neural_urn,get_user,get_user_preferences,get_user_features)
        target_prenormalized = max.(urn_contextual_state,0.01f0)
        target_normalized = target_prenormalized/sum(target_prenormalized) * N_balls
        target_normalized[winner] += 1.
        target_normalized[looser] -= 1.
        distilled_data = max.(urn_contextual_state,Float32(0.0001))
        distilled_data = distilled_data/sum(distilled_data) 
        push!(data_distillation, (user,user_feature, distilled_data))
        push!(learning_data, (user_feature, target_normalized))
        end
        for i in 1:1
        Flux.train!(loss, neural_urn, learning_data, opt)
        end
        
        u = rand()
        if u<p_random
            user,user_feature,winner,looser,urn_contextual_state = get_voter_and_compare(nb_alternative,neural_urn,get_user,get_user_preferences,get_user_features)
            target_prenormalized = max.(urn_contextual_state,0.01f0)
            target_normalized = target_prenormalized/sum(target_prenormalized) * N_balls
            winner, looser = sample(1:nb_alternative, 2, replace=false)
            target_normalized[winner] += 1
            target_normalized[looser] -= 1
        for i in 1:1
            Flux.train!(loss, neural_urn, [(user_feature, target_normalized)], opt)
        end
    end
    end
    return neural_urn,data_distillation
end

function learn_distilled_urn(nb_alternative::Int64,nb_feature::Int64,data_distillation::Vector{Tuple{Vector{Float32},Vector{Float32}}};opt=Adam(0.01),nb_steps=100)
    
    model = Chain(
        Dense(nb_feature, 32, relu),  
        Dense(32, 32, relu),          
        Dense(32, nb_alternative)    
    )
    loss(model, x, y) = Flux.Losses.crossentropy(softmax(model(x)), y)
    opt = Flux.setup(Adam(), model)
    #batch = [(x,Flux.onehot(y, 1:nb_alternative)) for (x,y) in data_distillation]
    batch = [(x,y) for (x,y) in data_distillation]
    batch=batch[length(batch)÷2:end]
    for _ in 1:nb_steps
            mini_batch = batch[rand(1:end, 16)]
            Flux.train!(loss, model, mini_batch, opt)
    end
    return model
end

